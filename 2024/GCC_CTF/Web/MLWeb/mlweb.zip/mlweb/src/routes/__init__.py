from routes.routes_admin import bp_admin
from routes.routes_auth import bp_auth
from routes.routes_user import bp_user