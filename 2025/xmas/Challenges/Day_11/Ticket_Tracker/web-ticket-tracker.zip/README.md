# TicketTracker

## Challenge

>   Take Santa's sleigh to navigate through the depths of Ruby, where you will find the flag.
>
>   Author : `Elweth` 

- Catégorie: Web
- Difficulté: Hard

## Déploiement

- Docker compose

```bash
docker compose down -v
docker compose build --no-cache
docker compose up
``` 

Le challenge est exposé via le port 10000 du container.