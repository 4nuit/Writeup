# SantaPresents
## Board
- microcontroller: Pico-H
- processor: RP2040 (Dual ARM Cortex-M0+ cores)

## LCD - Screen
- lcd 1602

## Button
- push-button - 4 pins

