package main

import (
	"crypto/subtle"
	"fmt"
	"os"
)

const EXIT_CODE_INVALID_SECRET = 42
const EXIT_CODE_VALID_SECRET = 0

const FLAG_PATH = "/base-challenge/flag"
const CONFIG_SECRET_PATH = "/base-challenge/config/secret"

func main() {
	if len(os.Args) != 3 {
		fmt.Println("invalid args")
		os.Exit(EXIT_CODE_INVALID_SECRET)
	}
	inputSecret := os.Args[1]
	inputFlag := os.Args[2]

	flag, _ := os.ReadFile(FLAG_PATH)
	configSecret, _ := os.ReadFile(CONFIG_SECRET_PATH)

	if subtle.ConstantTimeCompare(configSecret, []byte(inputSecret)) == 0 {
		fmt.Println("invalid secret")
		os.Exit(EXIT_CODE_INVALID_SECRET)
	}

	os.WriteFile(FLAG_PATH, []byte(inputFlag), 0600)

	fmt.Println(string(flag))

	os.Exit(EXIT_CODE_VALID_SECRET)
}
