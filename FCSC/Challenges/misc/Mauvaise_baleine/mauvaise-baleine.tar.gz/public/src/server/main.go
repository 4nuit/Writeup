package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/client"
)

const (
	IMAGE_NAME             = "challenge-mauvaise-baleine-base-challenge-image"
	CONTAINER_WAIT_TIMEOUT = 10 * time.Second
)

var cli *client.Client

func log(format string, a ...any) {
	fmt.Fprintf(os.Stderr, "[log] %s\n", fmt.Sprintf(format, a...))
}

func newImageTag() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func main() {
	if err := start(); err != nil {
		log("start failed: %v", err)
		fmt.Println("Une erreur interne est survenue.")
		os.Exit(1)
	}

	fmt.Println("À la prochaine !")
}

func start() error {
	sessionImageTag, err := newImageTag()
	if err != nil {
		return fmt.Errorf("failed to init session image tag: %v", err)
	}
	sessionImage := fmt.Sprintf("%s:%s", IMAGE_NAME, sessionImageTag)
	log("new session %s", sessionImageTag)
	defer log("end of session %s", sessionImageTag)

	ctx, cancel := signal.NotifyContext(context.Background(), os.Kill, os.Interrupt, syscall.SIGPIPE)
	defer cancel()

	// Create the docker client
	cli, err = client.NewClientWithOpts(client.FromEnv)
	if err != nil {
		return fmt.Errorf("creating docker client: %v", err)
	}
	cli.NegotiateAPIVersion(ctx)

	// Let's start by tagging an image for this session.
	if err := cli.ImageTag(ctx, IMAGE_NAME, sessionImage); err != nil {
		return fmt.Errorf("creating image tag for session: %v", err)
	}
	defer func() {
		if _, err := cli.ImageRemove(context.TODO(), sessionImage, types.ImageRemoveOptions{
			Force:         true,
			PruneChildren: true,
		}); err != nil {
			log("failed to remove image: %v", err)
		}
	}()

	fmt.Println(`Entrer "help" pour le message d'aide`)

	// Introduce a pipe to be able to simulate a call to close stdin
	pr, pw := io.Pipe()
	reader := bufio.NewReaderSize(pr, 255)

	go func() {
		io.Copy(pw, os.Stdin) // ignore errors
		pw.Close()            // ignore errors
	}()
	go func() {
		for {
			<-ctx.Done()
			pw.Close() // ignore errors
		}
	}()

	for {
		fmt.Print("> ")

		line, isPrefix, err := reader.ReadLine()
		if err != nil {
			if err == io.EOF && len(line) == 0 {
				return nil
			} else if err != io.EOF {
				return fmt.Errorf("reading stdin: %v", err)
			}
		}
		if isPrefix {
			return fmt.Errorf("reading stdin: cmd too long")
		}

		cmd, args, _ := strings.Cut(string(line), " ")

		switch cmd {
		case "help":
			help()
		case "change_flag":
			splitArgs := strings.Split(args, " ")
			if len(splitArgs) != 2 {
				fmt.Printf("Arguments invalides pour la commande %q.\n", cmd)
				help()
				break
			}
			secret := splitArgs[0]
			newFlag := splitArgs[1]
			if err := changeFlag(ctx, sessionImage, secret, newFlag); err != nil {
				return fmt.Errorf("error during change_flag: %v", err)
			}
		case "exit":
			return nil
		default:
			fmt.Printf("Commande %q invalide.\n", cmd)
			help()
		}
	}
}

func help() {
	fmt.Println(`
Commandes disponibles:

help                         Ce message d'aide
change_flag <secret> <flag>  Écrase le flag <flag> protégé par <secret> et retourne l'ancien
exit                         À la prochaine !
	`)
}

func changeFlag(ctx context.Context, containerImage string, secret string, newFlag string) error {
	log("change flag with secret %q; new flag: %q", secret, newFlag)

	// Create the container
	containerStopTimeout := 1
	containerCreateResp, err := cli.ContainerCreate(
		ctx,
		&container.Config{
			Image:           containerImage,
			Cmd:             []string{fmt.Sprintf("/change_flag %q %q", secret, newFlag)},
			NetworkDisabled: true,
			StopTimeout:     &containerStopTimeout,
			Tty:             true,
		},
		&container.HostConfig{
			UsernsMode: "host",
			CapDrop:    []string{"all"},
			Resources: container.Resources{
				Memory:   32 * 1024 * 1024, // 32 Mb
				NanoCPUs: 50 * 1000 * 1000, // 0.05 CPU
			},
		},
		nil,
		nil,
		"",
	)
	if err != nil {
		return fmt.Errorf("create container: %w", err)
	}
	containerID := containerCreateResp.ID

	// Defer its deletion, unless in case of a panic, no container will be left
	// not killed.
	defer func() {
		if err := cli.ContainerRemove(context.TODO(), containerID, types.ContainerRemoveOptions{
			Force: true,
		}); err != nil {
			log("failed to remove container: %v", err)
		}
	}()

	// Put a cap on the time the `change_flag` command can take, just in case.
	ctxContainerWait, cancelContainerWait := context.WithTimeout(ctx, CONTAINER_WAIT_TIMEOUT)
	defer cancelContainerWait()

	// Prepare the wait before starting the container.
	respChan, errChan := cli.ContainerWait(
		ctxContainerWait,
		containerID,
		container.WaitConditionNextExit,
	)

	// Actually start the container and exec the `change_flag` script.
	if err := cli.ContainerStart(ctx, containerID, types.ContainerStartOptions{}); err != nil {
		return fmt.Errorf("start container: %w", err)
	}

	var waitResp container.WaitResponse
	select {
	case err := <-errChan:
		return fmt.Errorf("wait container stop: %w", err)
	case waitResp = <-respChan:
	}

	if waitResp.Error != nil {
		return fmt.Errorf("response to wait container stop: %s", waitResp.Error.Message)
	}
	if waitResp.StatusCode == 42 {
		fmt.Println("invalid secret")
		return nil
	}

	// Retrieve the stdout, should contain the replaced flag.
	reader, err := cli.ContainerLogs(ctx, containerID, types.ContainerLogsOptions{
		ShowStdout: true,
	})
	if err != nil {
		return fmt.Errorf("container logs: %w", err)
	}
	defer reader.Close() // ignore errors on purpose

	// len("FCSC{xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx}") = 70
	rawFlag := make([]byte, 70)
	n, err := reader.Read(rawFlag)
	if err != nil && err != io.EOF {
		return fmt.Errorf("read flag: %w", err)
	}
	fmt.Printf("flag: %s", string(rawFlag[:n])) // here it is

	// Commit the container to the original image, so that the flag is updated
	// and available to others that want to retrieve it.
	if _, err = cli.ContainerCommit(ctx, containerID, types.ContainerCommitOptions{
		Reference: containerImage,
	}); err != nil {
		return fmt.Errorf("commit container: %w", err)
	}

	return nil
}
