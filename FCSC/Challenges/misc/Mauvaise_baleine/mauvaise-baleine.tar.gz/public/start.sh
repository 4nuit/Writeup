#!/usr/bin/env bash

set -euo pipefail

docker build --tag challenge-mauvaise-baleine-base-challenge-image:latest src/base-challenge-image
docker compose up -d --build
