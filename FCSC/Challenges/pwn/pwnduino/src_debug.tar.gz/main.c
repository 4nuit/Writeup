#include <avr/io.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>

#include "main.h"
#include "uart.h"

#if defined(PRODUCTION)
#include "secrets_prod.h"
#else
#include "secrets_debug.h"
#endif
#define SECRET_SIZE (sizeof(secret) - 1)

const char *get_secret_address(void)
{
	return secret;
}

unsigned char compute_secret_crc(void)
{
	unsigned char crc = 0, i;

	const char *s = get_secret_address();

	for(i = 0; i < SECRET_SIZE; i++){
		crc ^= pgm_read_byte(s[i]);
	}

	return crc;
}

int passwd_check(void){
    	char buff[sizeof(passwd)];
	unsigned int i;
	int check;

	memset(buff, 0, sizeof(buff));
	i = 0;
	while(1){
		buff[i] = uart_get();
		if(buff[i] == '\n'){
			buff[i] = 0;
			break;
		}
		i++;
	}
	check = 0;
	for(i = 0; i < sizeof(passwd); i++){
		check |= (buff[i] ^ pgm_read_byte(&(passwd[i])));
	}
	return check;
}

int main(void) {    
    uart_init();
    uart_flush();
    
    uart_puts("=== Welcome!\r\n");
    while(1) {
		uart_puts("Please enter your passphrase to compute CRC:\r\n");
		if(passwd_check() == 0){
			unsigned char crc;
			uart_puts("OK! Computing the secret CRC\r\n");
			crc = compute_secret_crc();
			uart_puts("Writing CRC to EEPROM ...\r\n");
			eeprom_write_byte(0, crc);
		}
		else{
			uart_puts("KO :-( Bad password ...\r\n");
		}
    }
    return 0;
}
