const char secret[] PROGMEM = "FCSC{XXXXXXXXXXXXXXXX}";
const char passwd[] PROGMEM = "YYYYYYYYYYYYYYYY";
