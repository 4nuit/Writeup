void uart_init();
void uart_puts(char *send);
char uart_get();
void uart_putc(char data);
void uart_puts_p(const char *str);
